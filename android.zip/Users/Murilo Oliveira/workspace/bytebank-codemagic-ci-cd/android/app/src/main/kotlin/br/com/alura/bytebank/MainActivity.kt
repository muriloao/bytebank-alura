package br.com.muriloao.bytebank

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
